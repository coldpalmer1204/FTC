package org.firstinspires.ftc.teamcode;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.roadrunner.MecanumDrive;
//import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;


@Autonomous(name="AutoEscape")
public class AutoEscapeNoRoadrunner extends LinearOpMode {
    boolean blue = true;
    BunsBot buns =null;

    @Override
    public void runOpMode() throws InterruptedException {

        buns = new BunsBot(hardwareMap, telemetry, this);
        Pose2d startPose = new Pose2d(0, 0, Math.toRadians(0));
        MecanumDrive myDrive = new MecanumDrive(hardwareMap, startPose);

        buns.drivetrain.setDrivePower(.2,.2,.2,.2);
        sleep(10000000);

//
//        while (opModeInInit()) {
//            if (gamepad1.x) {
//                blue=true;
//            } else if (gamepad1.b) {
//                blue=false;
//            }
//
//            buns.updateOuttake();
//
//            telemetry.addData("Alliance: ", blue ? "Blue" : "Red");
//            telemetry.update();
//        }
//
//        waitForStart();
//        for (int i = 0; i < 50; i++) {
//            buns.outtakeState = BunsBot.States.UP;
//            buns.updateOuttake();
//        }
//
//        sleep(250);
//        buns.backwards();
//        sleep(250);
//        if (blue) {
//            buns.strafeLeft();
//        } else {
//            buns.strafeRight();
//        }
//        sleep(500);
//        buns.drivetrain.setDrivePower(0, 0, 0, 0);


        buns.outtakeState = BunsBot.States.DOWN;
        buns.resetTimer();
        while (opModeInInit()) {


        }

        waitForStart();



    }
    public void shoot() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(1000);
        buns.outtakeState = BunsBot.States.DOWN;
        buns.updateOuttake();
        buns.sleep(500);

    }
    public void pop() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(20);
        buns.outtakeState = BunsBot.States.DOWN;

    }
}
