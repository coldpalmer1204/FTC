package org.firstinspires.ftc.teamcode;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.roadrunner.MecanumDrive;

@Autonomous(name="AutoWithoutPinpointv2")
public class AutoWithoutPinpointv2 extends LinearOpMode {
    boolean blue = true;
    BunsBot buns =null;

    @Override
    public void runOpMode() throws InterruptedException {

        buns = new BunsBot(hardwareMap, telemetry, this);
        Pose2d startPose = new Pose2d(0, 0, Math.toRadians(0));
        MecanumDrive myDrive = new MecanumDrive(hardwareMap, startPose);
        Action shootPath = myDrive.actionBuilder(startPose)
                .lineToX(-5)
                .build();
        Action shootPath2 = myDrive.actionBuilder(startPose)
                .lineToX(-8)
                .build();
        Action turn = myDrive.actionBuilder(startPose)
                .turn(Math.toRadians(35))
                .build();
        Action forwardIntake = myDrive.actionBuilder(startPose)
                .lineToX(5)
                .build();
        Action backIntake = myDrive.actionBuilder(startPose)
                .lineToX(-5)
                .build();
        Action reverseTurn = myDrive.actionBuilder(startPose)
                .turn(Math.toRadians(-35))
                .build();
        Action shootPathReverse = myDrive.actionBuilder(startPose)
                .lineToX(8)
                .build();



//
//        while (opModeInInit()) {
//            if (gamepad1.x) {
//                blue=true;
//            } else if (gamepad1.b) {
//                blue=false;
//            }
//
//            buns.updateOuttake();
//
//            telemetry.addData("Alliance: ", blue ? "Blue" : "Red");
//            telemetry.update();
//        }
//
//        waitForStart();
//        for (int i = 0; i < 50; i++) {
//            buns.outtakeState = BunsBot.States.UP;
//            buns.updateOuttake();
//        }
//
//        sleep(250);
//        buns.backwards();
//        sleep(250);
//        if (blue) {
//            buns.strafeLeft();
//        } else {
//            buns.strafeRight();
//        }
//        sleep(500);
//        buns.drivetrain.setDrivePower(0, 0, 0, 0);


        buns.outtakeState = BunsBot.States.DOWN;
        buns.resetTimer();
        while (opModeInInit()) {
            buns.updateOuttake();
        }

        waitForStart();

        //Actions.runBlocking(shootPath);
        shoot();
        Actions.runBlocking(shootPath2);
        sleep(500);
        Actions.runBlocking(turn);
        buns.intake();
        Actions.runBlocking(forwardIntake);
        sleep(300);
        buns.turnOffIntake();
        sleep(300);
        Actions.runBlocking(backIntake);
        sleep(500);
        Actions.runBlocking(reverseTurn);
        sleep(300);
        Actions.runBlocking(shootPathReverse);
        sleep(300);
        shoot();







    }
    public void shoot() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(1000);
        buns.outtakeState = BunsBot.States.DOWN;
        buns.updateOuttake();
        buns.sleep(500);

    }
    public void pop() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(20);
        buns.outtakeState = BunsBot.States.DOWN;

    }
}
