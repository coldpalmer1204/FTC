package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.BunsBot;
import org.firstinspires.ftc.teamcode.subsystems.Drivetrain;

@TeleOp(name="BBL Hanny")
public class Hansens_BBL extends LinearOpMode {
    BunsBot buns = null;
    ElapsedTime popTime = new ElapsedTime();
    @Override
    public void runOpMode() throws InterruptedException {
        buns = new BunsBot(hardwareMap, telemetry, this);


        buns.outtakeState = BunsBot.States.DOWN;
        buns.drivetrain.driveState = Drivetrain.DriveState.DRIVE;
        buns.resetTimer();
        while (opModeInInit()) {
            buns.updateOuttake();
        }

        waitForStart();
        buns.reset();

        while (opModeIsActive()) {



            if (gamepad1.left_bumper && popTime.time() > 1) {
                poping(this);
            } else if (gamepad1.left_trigger > 0.5 && popTime.time() > 1) {
                pop(this);
            } else if (gamepad1.right_trigger > 0.5) {
                buns.outtakeState = BunsBot.States.UP;
            } else {
                buns.outtakeState = BunsBot.States.DOWN;
            }


            if (gamepad1.dpad_up) {
                buns.resetOuttake();
            }
            if (gamepad1.right_bumper) {
                buns.footState = BunsBot.States.DOWN;
            } else if (gamepad1.dpad_down) {
                buns.footState = BunsBot.States.UP;
            } else {
                buns.footState = BunsBot.States.HOLD;
            }

            if (gamepad1.x) {
                buns.intake();
            } else if (gamepad1.b) {
                buns.turnOffIntake();
            } else if (gamepad1.a) {
                buns.outtakeOnTheIntake();
            }



            buns.drivetrain.drive(gamepad1);
            buns.update();
            telemetry.addData("Motor Powers: ", buns.outtake1.getPower() + " : " + buns.outtake2.getPower());
            telemetry.addData("Outtake State: ", buns.outtakeState);
            telemetry.addData("Outtake Pos: ", buns.outtake1.getCurrentPosition());
            telemetry.addData("Foot State: ", buns.footState);
            telemetry.update();
        }

    }
    public void pop(LinearOpMode opMode) {
        buns.outtakeState = BunsBot.States.UP;
        speel(30, opMode);
        buns.outtakeState = BunsBot.States.DOWN;
        popTime.reset();



    }
    public void poping(LinearOpMode opMode) {
        buns.outtakeState = BunsBot.States.UP;
        speel(55, opMode);
        buns.outtakeState = BunsBot.States.DOWN;
        popTime.reset();



    }
    public void speel(double ms, LinearOpMode opMode) {
        double time = System.currentTimeMillis();
        while (!opMode.isStopRequested() &&  System.currentTimeMillis() - time < ms) {
            buns.drivetrain.drive(gamepad1);
            buns.update();
        }
    }

}