package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.hardware.limelightvision.*;
import java.util.List;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.vision.VisionPortal;
import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;

import java.util.List;

public class ATag {

    private Limelight3A limelight;
    private int tagId = -1;   // -1 = no tag detected
    private static final int[] GOAL_TAG_IDS = {20,24};
    private double tx = 0;
    private boolean aimedAtGoal = false;
    private int goalTagId = -1;
    public ATag(HardwareMap hardwareMap) {
        limelight = hardwareMap.get(Limelight3A.class, "Ethernet Device");
        limelight.pipelineSwitch(0);
        limelight.start();
    }

    // Call this ONCE PER LOOP
    public void update() {
        LLResult result = limelight.getLatestResult();
        aimedAtGoal = false;
        goalTagId = -1;
        tx = 0;

        if (result == null || !result.isValid()) return;

        List<LLResultTypes.FiducialResult> fiducials = result.getFiducialResults();
        if (fiducials.isEmpty()) return;

        LLResultTypes.FiducialResult bestGoalTag = null;

        for (LLResultTypes.FiducialResult tag : fiducials) {
            int id = tag.getFiducialId();

            // --- For turret: only goal tags 20 or 24 ---
            if (id == 20 || id == 24) {
                if (bestGoalTag == null || tag.getTargetArea() > bestGoalTag.getTargetArea()) {
                    bestGoalTag = tag;
                }
            }

            // --- For color: update tagId if Obelisk tag ---
            if (id == 21 || id == 22 || id == 23) {
                tagId = id; // used by colorIDName()
            }
        }

        // If a valid goal tag is found, save info for turret
        if (bestGoalTag != null) {
            goalTagId = bestGoalTag.getFiducialId();
            tx = bestGoalTag.getTargetXDegrees();  // horizontal offset for turret
            aimedAtGoal = true;
        }
    }

    // --- Color functions ---
    public int colorIDNumber() {
        return tagId;
    }

    public String colorIDName() {
        if (tagId == 22) return "P-G-P";
        if (tagId == 23) return "P-P-G";
        if (tagId == 21) return "G-P-P";
        return "None";
    }

    // --- Turret aiming functions ---
    public boolean hasGoal() {
        return aimedAtGoal;
    }

    public double getTx() {
        return tx;
    }

    public int getGoalTagId() {
        return goalTagId;
    }
}
