package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;


@Autonomous(name="AutoWithoutPinpointThatMoves")
public class AutoWithoutPinpointThatMoves extends LinearOpMode {
    boolean blue = true;
    BunsBot buns =null;

    @Override
    public void runOpMode() throws InterruptedException {

        buns = new BunsBot(hardwareMap, telemetry, this);



//
//        while (opModeInInit()) {
//            if (gamepad1.x) {
//                blue=true;
//            } else if (gamepad1.b) {
//                blue=false;
//            }
//
//            buns.updateOuttake();
//
//            telemetry.addData("Alliance: ", blue ? "Blue" : "Red");
//            telemetry.update();
//        }
//
//        waitForStart();
//        for (int i = 0; i < 50; i++) {
//            buns.outtakeState = BunsBot.States.UP;
//            buns.updateOuttake();
//        }
//
//        sleep(250);
//        buns.backwards();
//        sleep(250);
//        if (blue) {
//            buns.strafeLeft();
//        } else {
//            buns.strafeRight();
//        }
//        sleep(500);
//        buns.drivetrain.setDrivePower(0, 0, 0, 0);


        buns.outtakeState = BunsBot.States.DOWN;
        buns.resetTimer();
        while (opModeInInit()) {
            buns.updateOuttake();
        }

        waitForStart();
        buns.reset();

        //Actions.runBlocking(shootPath);
        shoot();
        //buns.drivetrain.setDrivePower(-1,-1,-1,-1);
        //sleep(1000);




    }
    public void shoot() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(1000);
        buns.outtakeState = BunsBot.States.DOWN;
        buns.updateOuttake();
        buns.sleep(500);
        buns.drivetrain.setDrivePower(-1,-1,-1,-1);
        sleep(400);


    }
    public void pop() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(20);
        buns.outtakeState = BunsBot.States.DOWN;

    }
}
