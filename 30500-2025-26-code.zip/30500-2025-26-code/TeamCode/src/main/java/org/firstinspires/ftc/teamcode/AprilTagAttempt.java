import com.qualcomm.robotcore.eventloop.opmode.Disabled;
//package org.firstinspires.ftc.teamcode;
//
//import android.util.Size;
//
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.Disabled;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.OpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//
//import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
//import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
//import org.firstinspires.ftc.robotcore.external.hardware.camera.lim
//
//import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
//import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
//import org.firstinspires.ftc.robotcore.external.navigation.Position;
//import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
//import org.firstinspires.ftc.vision.VisionPortal;
//import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
//import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;
//import java.util.List;
//@TeleOp
//public class AprilTagAttempt extends LinearOpMode {
//
//    public void runOpMode() throws InterruptedException{
//
//        AprilTagProcessor tagProcessor = new AprilTagProcessor.Builder()
//                .setDrawAxes(true)
//                .setDrawCubeProjection(true)
//                .build();
//        VisionPortal visionPortal = new VisionPortal.Builder()
//                .addProcessor(tagProcessor)
//                .setCamera(hardwareMap.get(WebcamName.class, "Limelight"))
//                .setCameraResolution( new Size(640,480))
//                .build();
//
//        waitForStart();
//
//        while (!isStopRequested() && opModeIsActive()){
//            if (tagProcessor.getDetections().size() > 0){
//
//                AprilTagDetection tag = tagProcessor.getDetections().get(0);
//
//               telemetry.addData("x", tag.ftcPose.x);
//               telemetry.addData("y", tag.ftcPose.y);
//               telemetry.addData("z", tag.ftcPose.z);
//               telemetry.addData("yaw", tag.ftcPose.yaw);
//               telemetry.addData("roll", tag.ftcPose.roll);
//               telemetry.addData("pitch", tag.ftcPose.pitch);
//            }
//            telemetry.update();
//
//        }
//    }
//
//
//}
