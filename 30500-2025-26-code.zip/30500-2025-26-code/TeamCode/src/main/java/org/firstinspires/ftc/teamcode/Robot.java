package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;
import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.subsystems.Drivetrain;
import org.firstinspires.ftc.teamcode.subsystems.Intake;
@Disabled
public class Robot {
    private Telemetry telemetry;
    private HardwareMap hwMap;
    private LinearOpMode opMode;
    public Drivetrain drivetrain;
    public Intake intake;



    public Robot(HardwareMap hwMap, Telemetry telemetry) {
        this.telemetry = telemetry;
        this.hwMap = hwMap;
        this.opMode = opMode;
        drivetrain = new Drivetrain(hwMap, telemetry);

    }
}
