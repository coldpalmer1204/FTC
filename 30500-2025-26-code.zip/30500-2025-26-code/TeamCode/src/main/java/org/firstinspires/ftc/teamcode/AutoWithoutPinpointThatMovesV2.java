package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;


@Autonomous(name="AutoWithoutPinpointThatMovesV2")
public class AutoWithoutPinpointThatMovesV2 extends LinearOpMode {
    boolean blue = true;
    BunsBot buns =null;

    @Override
    public void runOpMode() throws InterruptedException {

        buns = new BunsBot(hardwareMap, telemetry, this);



//
//        while (opModeInInit()) {
//            if (gamepad1.x) {
//                blue=true;
//            } else if (gamepad1.b) {
//                blue=false;
//            }
//
//            buns.updateOuttake();
//
//            telemetry.addData("Alliance: ", blue ? "Blue" : "Red");
//            telemetry.update();
//        }
//
//        waitForStart();
//        for (int i = 0; i < 50; i++) {
//            buns.outtakeState = BunsBot.States.UP;
//            buns.updateOuttake();
//        }
//
//        sleep(250);
//        buns.backwards();
//        sleep(250);
//        if (blue) {
//            buns.strafeLeft();
//        } else {
//            buns.strafeRight();
//        }
//        sleep(500);
//        buns.drivetrain.setDrivePower(0, 0, 0, 0);


        buns.outtakeState = BunsBot.States.DOWN;
        buns.resetTimer();
        while (opModeInInit()) {
            buns.updateOuttake();
        }

        waitForStart();
        buns.reset();

        //Actions.runBlocking(shootPath);
        shootEvents();
        //buns.drivetrain.setDrivePower(-1,-1,-1,-1);
        //sleep(1000);




    }
    public void shoot() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(1000);
        buns.outtakeState = BunsBot.States.DOWN;
        buns.updateOuttake();
        buns.sleep(500);


    }
    public void shootEvents() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(1000);
        buns.outtakeState = BunsBot.States.DOWN;
        buns.updateOuttake();
        buns.sleep(500);
        buns.drivetrain.setDrivePower(-1,-1,-1,-1);
        sleep(1000);
        buns.drivetrain.setDrivePower(0.5,-0.5,0.5,-0.5);
        sleep(600);
        buns.intake();
        buns.drivetrain.setDrivePower(0.5,0.5,0.5,0.5);
        sleep(300);
        buns.turnOffIntake();
        buns.drivetrain.setDrivePower(-0.5,-0.5,-0.5,-0.5);
        sleep(300);
        buns.drivetrain.setDrivePower(-0.5,0.5,-0.5,0.5);
        sleep(200);
        buns.drivetrain.setDrivePower(0.5,0.5,0.5,0.5);
        sleep(600);
        shoot();




    }
    public void pop() {
        buns.outtakeState = BunsBot.States.UP;
        buns.updateOuttake();
        buns.sleep(20);
        buns.outtakeState = BunsBot.States.DOWN;

    }
}
