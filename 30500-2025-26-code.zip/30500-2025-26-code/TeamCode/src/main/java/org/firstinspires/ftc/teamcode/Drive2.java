//package org.firstinspires.ftc.teamcode;//package org.firstinspires.ftc.teamcode.opmodes;
//
//import com.qualcomm.robotcore.eventloop.opmode.Disabled;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//
////import org.firstinspires.ftc.teamcode.subsystems.Pit.Pit;
////import org.firstinspires.ftc.teamcode.utils.Globals;
//// ts is for gavven cuz gavven is
//@TeleOp(name = "org.firstinspires.ftc.teamcode.Drive2")
//@Disabled
//public class Drive2 extends LinearOpMode {
//    private Robot robot;
//
//    private long lastLoopTime;
//
//    private int hangStep = 0;
//
//    private enum AnalogState {
//        EXTENSION,
//        DRIVE
//    }
//    boolean optionsPrevious = false;
//    boolean startPrevious = false;
//
//    private AnalogState analogState = AnalogState.DRIVE;
//
//    @Override
//    public void runOpMode() {
//        robot = new Robot(hardwareMap, telemetry, this);
////        Globals.running = false;
//        waitForStart();
//        while (opModeIsActive()) {
//            long currentTime = System.currentTimeMillis();
//            long deltaTime = currentTime - lastLoopTime;
//
//
//            lastLoopTime = currentTime;
//            telemetry.addData("Loop time", "%d ms", deltaTime);
//
//
//
//            /************************GAMEPAD 1************************/
//            robot.drivetrain.drive(gamepad1); robot.intake.spin(gamepad1);}}}