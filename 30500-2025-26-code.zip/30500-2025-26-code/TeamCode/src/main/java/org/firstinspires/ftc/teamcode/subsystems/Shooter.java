package org.firstinspires.ftc.teamcode.subsystems;

//import com.acmerobotics.dashboard.config.Config;
//import com.acmerobotics.roadrunner.ftc.SparkFunOTOSCorrected;
import com.qualcomm.hardware.sparkfun.SparkFunOTOS;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.NormalizedColorSensor;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;
import com.qualcomm.robotcore.hardware.Servo;


import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.subsystems.Limelight;

//import org.firstinspires.ftc.teamcode.utils.P;
//import org.firstinspires.ftc.teamcode.utils.PID;

import java.util.Queue;

//@Config

public class Shooter {
    Telemetry telemetry;
    Limelight limelight;
    NormalizedColorSensor leftColorSensor;
    NormalizedColorSensor middleColorSensor;
    NormalizedColorSensor rightColorSensor;

    public AnalogInput absEncoder = null;

    public DigitalChannel limitSwitch = null;

    public Servo leftServo = null;
    public Servo middleServo = null;
    public Servo rightServo = null;
    public Servo aimer = null;

    public DcMotor shooterMotor = null;

    int [] list = new int[3];

// green is 0 purple is 1 none/unkown is 2
    int[] motif21 = {0, 1, 1};
    int[] motif22 = {1, 0, 1};
    int[] motif23 = {1, 1, 0};

    public int aprilTag;

    public enum shooterStates {
        IDLE,
        PULLITBACK,
        LAUNCHFORPATTERN,
        LAUNCHLEFT,
        LAUNCHMIDDLE,
        LAUNCHRIGHT;

    }
    public enum leftDetectedColor {
        GREEN,
        PURPLE,
        UNKOWN;
    }
    public enum middleDetectedColor {
        GREEN,
        PURPLE,
        UNKOWN;
    }
    public enum rightDetectedColor {
        GREEN,
        PURPLE,
        UNKOWN;
    }
    public shooterStates SHOOTERSTATES = shooterStates.IDLE;
    public leftDetectedColor LEFTDETECTEDCOLOR = leftDetectedColor.UNKOWN;
    public middleDetectedColor MIDDLEDETECTEDCOLOR = middleDetectedColor.UNKOWN;
    public rightDetectedColor RIGHTDETECTEDCOLOR = rightDetectedColor.UNKOWN;




    public Shooter (HardwareMap hardwareMap, Telemetry telemetry){
        leftServo = hardwareMap.get(Servo.class, "left_servo");
        rightServo = hardwareMap.get(Servo.class, "right_servo");
        middleServo = hardwareMap.get(Servo.class, "middle_servo");

        shooterMotor = hardwareMap.get(DcMotor.class, "shooter_motor");

        limitSwitch = hardwareMap.get(DigitalChannel.class, "limitSwitch");
        absEncoder = hardwareMap.get(AnalogInput.class, "absolute_encoder");
        leftColorSensor = hardwareMap.get(NormalizedColorSensor.class, "left_color_sensor");
        middleColorSensor = hardwareMap.get(NormalizedColorSensor.class, "middle_color_sensor");
        rightColorSensor = hardwareMap.get(NormalizedColorSensor.class, "right_color_sensor");

        aimer = hardwareMap.get(Servo.class, "aim");

        shooterMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        limitSwitch.setMode(DigitalChannel.Mode.INPUT);




    }
    public void update(){
        switch (SHOOTERSTATES) {
            case IDLE:
                shooterMotor.setPower(0);
                break;
            case PULLITBACK:
                PullOutGame(200);
                break;
            case LAUNCHFORPATTERN:
                int leftIsGreen = 2;
                int midIsGreen = 2;
                int rightIsGreen = 2;
                int aprilTagID = limelight.scan();
                if (aprilTagID == 21){

                    getDetectedColorLeft(telemetry);
                    switch (LEFTDETECTEDCOLOR){
                        case GREEN:
                            leftIsGreen = 0;
                            break;
                        case PURPLE:
                            leftIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                        }

                    getDetectedColorMiddle(telemetry);
                    switch (MIDDLEDETECTEDCOLOR){
                        case GREEN:
                            midIsGreen = 0;
                            break;
                        case PURPLE:
                            midIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }

                    getDetectedColorRight(telemetry);
                    switch (RIGHTDETECTEDCOLOR){
                        case GREEN:
                            rightIsGreen = 0;
                            break;
                        case PURPLE:
                            rightIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }
                    list = new int[]{leftIsGreen, midIsGreen, rightIsGreen};
                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++) {
                            if (list[j] == motif21[i]) {
                                shootBallAtIndex(j);
                                list[j] = 0;
                                break;
                            }
                        }

                    }


                    }
                else if (aprilTagID == 22){
                    getDetectedColorLeft(telemetry);
                    switch (LEFTDETECTEDCOLOR){
                        case GREEN:
                            leftIsGreen = 0;
                            break;
                        case PURPLE:
                            leftIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }

                    getDetectedColorMiddle(telemetry);
                    switch (MIDDLEDETECTEDCOLOR){
                        case GREEN:
                            midIsGreen = 0;
                            break;
                        case PURPLE:
                            midIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }

                    getDetectedColorRight(telemetry);
                    switch (RIGHTDETECTEDCOLOR){
                        case GREEN:
                            rightIsGreen = 0;
                            break;
                        case PURPLE:
                            rightIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }
                    list = new int[]{leftIsGreen, midIsGreen, rightIsGreen};
                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++) {
                            if (list[j] == motif22[i]) {
                                // This is the ball that needs to be shot
                                shootBallAtIndex(j);
                                list[j] = 0;
                                break;
                            }
                        }

                    }

                }
                else if (aprilTagID == 23) {
                    getDetectedColorLeft(telemetry);
                    switch (LEFTDETECTEDCOLOR){
                        case GREEN:
                            leftIsGreen = 0;
                            break;
                        case PURPLE:
                            leftIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }

                    getDetectedColorMiddle(telemetry);
                    switch (MIDDLEDETECTEDCOLOR){
                        case GREEN:
                            midIsGreen = 0;
                            break;
                        case PURPLE:
                            midIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }

                    getDetectedColorRight(telemetry);
                    switch (RIGHTDETECTEDCOLOR){
                        case GREEN:
                            rightIsGreen = 0;
                            break;
                        case PURPLE:
                            rightIsGreen = 1;
                            break;
                        case UNKOWN:
                            break;
                    }
                    list = new int[]{leftIsGreen, midIsGreen, rightIsGreen};
                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++) {
                            if (list[j] == motif23[i]) {
                                // This is the ball that needs to be shot
                                shootBallAtIndex(j);
                                list[j] = 0;
                                break;
                            }
                        }

                    }
                }
            case LAUNCHLEFT:
                shootLeftBall();
                break;
            case LAUNCHMIDDLE:
                shootMidBall();
                break;
            case LAUNCHRIGHT:
                shootRightBall();
                break;
        }
    }
    public leftDetectedColor getDetectedColorLeft (Telemetry telemetry) {
       NormalizedRGBA colors = leftColorSensor.getNormalizedColors();

       float normRed, normGreen, normBlue;
       normRed = colors.red / colors.alpha;
       normGreen = colors.green / colors.alpha;
       normBlue = colors.blue / colors.alpha;

       telemetry.addData("red", normRed);
       telemetry.addData("green", normGreen);
       telemetry.addData("blue", normBlue);

       return leftDetectedColor.UNKOWN;

    }
    public middleDetectedColor getDetectedColorMiddle (Telemetry telemetry) {
        NormalizedRGBA colors = middleColorSensor.getNormalizedColors();

        float normRed, normGreen, normBlue;
        normRed = colors.red / colors.alpha;
        normGreen = colors.green / colors.alpha;
        normBlue = colors.blue / colors.alpha;

        telemetry.addData("red", normRed);
        telemetry.addData("green", normGreen);
        telemetry.addData("blue", normBlue);

        return middleDetectedColor.UNKOWN;

    }
    public rightDetectedColor getDetectedColorRight (Telemetry telemetry) {
        NormalizedRGBA colors = rightColorSensor.getNormalizedColors();

        float normRed, normGreen, normBlue;
        normRed = colors.red / colors.alpha;
        normGreen = colors.green / colors.alpha;
        normBlue = colors.blue / colors.alpha;

        telemetry.addData("red", normRed);
        telemetry.addData("green", normGreen);
        telemetry.addData("blue", normBlue);

        return rightDetectedColor.UNKOWN;

    }

    public double getEncoderVal() {
        return (absEncoder.getVoltage() / 3.3) * 360.0;
    }
    public void PullOutGame(double position) {
        double kP = 0.01;
        double error = 10;
        while (Math.abs(error) >= 0){
            error = position - getEncoderVal();
            double power = error * kP;
            shooterMotor.setPower(power);

            if (!limitSwitch.getState()) {
                break;
            }

        }

    }

    public void shootLeftBall() {

        leftServo.setPosition(-1);
    }
    public void shootMidBall() {
        middleServo.setPosition(-1);

    }
    public void shootRightBall() {
        rightServo.setPosition(-1);

    }
    public void shootBallAtIndex(int index) {
        switch (index) {
            case 0:
                shootLeftBall();
                break;
            case 1:
                shootMidBall();
                break;
            case 2:
                shootRightBall();
                break;
        }
    }
    public void aim () {
        aimer.setPosition(.2);
    }

}
