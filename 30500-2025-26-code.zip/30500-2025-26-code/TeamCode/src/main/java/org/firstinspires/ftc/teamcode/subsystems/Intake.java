

package org.firstinspires.ftc.teamcode.subsystems;
//
//import com.acmerobotics.dashboard.config.Config;
//import com.acmerobotics.roadrunner.ftc.SparkFunOTOSCorrected;
import com.qualcomm.hardware.sparkfun.SparkFunOTOS;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;

//import org.firstinspires.ftc.teamcode.utils.P;
//import org.firstinspires.ftc.teamcode.utils.PID;

import java.util.Queue;

//@Config
public class Intake {
    Telemetry telemetry;
    private CRServo leftFeeder = null;
    private CRServo rightFeeder = null;
    private DcMotor wallIntake = null;

    public enum intakeStates {
        IDLE,
        INTAKE,
        OUTTAKE,
        SHOOT;
    }

    public intakeStates INTAKESTATES = intakeStates.IDLE;


    public Intake(HardwareMap hardwareMap, Telemetry telemetry) {
        this.telemetry = telemetry;

        leftFeeder = hardwareMap.get(CRServo.class, "left_feeder");
        rightFeeder = hardwareMap.get(CRServo.class, "right_feeder");
        wallIntake = hardwareMap.get(DcMotor.class, "wall_intake");

        wallIntake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        wallIntake.setDirection(DcMotor.Direction.FORWARD);
        leftFeeder.setPower(0);
        rightFeeder.setPower(0);

        leftFeeder.setDirection(DcMotorSimple.Direction.REVERSE);


    }

    public void update() {
        switch (INTAKESTATES) {
            case IDLE:
                wallIntake.setPower(0);
                leftFeeder.setPower(0);
                rightFeeder.setPower(0);
                break;
            case INTAKE:
                intake(true);
                break;
            case OUTTAKE:
                outtake(true);
                break;
            case SHOOT:
                intake(false);
                break;
        }
    }


    public void intake(boolean yes) {
        wallIntake.setPower(-67);
        if (yes) {
            leftFeeder.setPower(1);
            rightFeeder.setPower(1);
        } else {
            leftFeeder.setPower(-1);
            rightFeeder.setPower(-1);
        }
    }

    public void outtake(boolean no) {
        wallIntake.setPower(67);
        if (no) {
            leftFeeder.setPower(1);
            rightFeeder.setPower(1);
        } else {
            leftFeeder.setPower(0);
            rightFeeder.setPower(0);
        }
    }

}