//package org.firstinspires.ftc.teamcode;
//
////import static com.qualcomm.robotcore.hardware.DcMotor.ZeroPowerBehavior.BRAKE;
////
////import com.qualcomm.robotcore.eventloop.opmode.OpMode;
////import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
////import com.qualcomm.robotcore.hardware.CRServo;
////import com.qualcomm.robotcore.hardware.DcMotor;
////import com.qualcomm.robotcore.hardware.DcMotorEx;
////import com.qualcomm.robotcore.hardware.DcMotorSimple;
////import com.qualcomm.robotcore.hardware.PIDFCoefficients;
////import com.qualcomm.robotcore.util.ElapsedTime;
//
////yooooooo awesome sauce
//
//@TeleOp(name = "StarterBotTeleop", group = "StarterBot")
//public class GavvenDrive extends OpMode {
//    final double FEED_TIME_SECONDS = 0.20;
//    final double STOP_SPEED = 0.0;
//    final double FULL_SPEED = 1.0;
//
//    double forward;
//    double strafe;
//    double turn;
//
//    final double LAUNCHER_TARGET_VELOCITY = 1125;
//    final double LAUNCHER_MIN_VELOCITY = 1075;
//
//    // Declare motors/servos
//    private DcMotor frontLeftMotor = null;
//    private DcMotor frontRightMotor = null;
//    private DcMotor backRightMotor = null;
//    private DcMotor backLeftMotor = null;
//    private DcMotorEx launcher = null;
//    private CRServo leftFeeder = null;
//    private CRServo rightFeeder = null;
//
//    ElapsedTime feederTimer = new ElapsedTime();
//
//    private enum LaunchState {
//        IDLE,
//        SPIN_UP,
//        LAUNCH,
//        LAUNCHING,
//    }
//
//    private LaunchState launchState;
//
//    @Override
//    public void init() {
//        launchState = LaunchState.IDLE;
//
//        frontLeftMotor = hardwareMap.get(DcMotor.class, "front_left_motor");
//        backLeftMotor = hardwareMap.get(DcMotor.class, "back_left_motor");
//        frontRightMotor = hardwareMap.get(DcMotor.class, "front_right_motor");
//        backRightMotor = hardwareMap.get(DcMotor.class, "back_right_motor");
//
//        // Reverse directions as needed
//        frontLeftMotor.setDirection(DcMotor.Direction.REVERSE);
//        backLeftMotor.setDirection(DcMotor.Direction.FORWARD);
//        frontRightMotor.setDirection(DcMotor.Direction.REVERSE);
//        backRightMotor.setDirection(DcMotor.Direction.FORWARD);
//
//        // Encoders
//        frontLeftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        backLeftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        frontRightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        backRightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//
//        launcher = hardwareMap.get(DcMotorEx.class, "launcher");
//        leftFeeder = hardwareMap.get(CRServo.class, "left_feeder");
//        rightFeeder = hardwareMap.get(CRServo.class, "right_feeder");
//
//        launcher.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        launcher.setZeroPowerBehavior(BRAKE);
//        launcher.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER, new PIDFCoefficients(300, 0, 0, 10));
//
//        // Feeders
//        leftFeeder.setPower(STOP_SPEED);
//        rightFeeder.setPower(STOP_SPEED);
//        leftFeeder.setDirection(DcMotorSimple.Direction.REVERSE);
//
//        telemetry.addData("Status", "Initialized");
//    }
//
//    @Override
//    public void loop() {
//        // Drive inputs
//        forward = -gamepad1.left_stick_y; // Negative to correct joystick inversion
//        strafe = gamepad1.left_stick_x;
//        turn = gamepad1.right_stick_x;
//
//        // Mecanum drive calculation
//        double frontLeftPower = forward + strafe + turn;
//        double backLeftPower = forward - strafe + turn;
//        double frontRightPower = forward - strafe - turn;
//        double backRightPower = forward + strafe - turn;
//
//        frontLeftMotor.setPower(frontLeftPower);
//        backLeftMotor.setPower(backLeftPower);
//        frontRightMotor.setPower(frontRightPower);
//        backRightMotor.setPower(backRightPower);
//
//        // Launcher manual control
//        if (gamepad1.y) {
//            launcher.setVelocity(LAUNCHER_TARGET_VELOCITY);
//        } else if (gamepad1.b) {
//            launcher.setVelocity(STOP_SPEED);
//        }
//
//        // Launch state machine
//        launch(gamepad1.right_bumper);
//
//        telemetry.addData("State", launchState);
//        telemetry.addData("motorSpeed", launcher.getVelocity());
//    }
//
//    void launch(boolean shotRequested) {
//        switch (launchState) {
//            case IDLE:
//                if (shotRequested) {
//                    launchState = LaunchState.SPIN_UP;
//                }
//                break;
//
//            case SPIN_UP:
//                launcher.setVelocity(LAUNCHER_TARGET_VELOCITY);
//                if (launcher.getVelocity() > LAUNCHER_MIN_VELOCITY) {
//                    launchState = LaunchState.LAUNCH;
//                }
//                break;
//
//            case LAUNCH:
//                leftFeeder.setPower(FULL_SPEED);
//                rightFeeder.setPower(FULL_SPEED);
//                feederTimer.reset();
//                launchState = LaunchState.LAUNCHING;
//                break;
//
//            case LAUNCHING:
//                if (feederTimer.seconds() > FEED_TIME_SECONDS) {
//                    launchState = LaunchState.IDLE;
//                    leftFeeder.setPower(STOP_SPEED);
//                    rightFeeder.setPower(STOP_SPEED);
//                }
//                break;
//        }
//    }
//}