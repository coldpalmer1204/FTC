package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.hardware.limelightvision.LLFieldMap;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.LLStatus;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.HardwareMap;
import org.firstinspires.ftc.teamcode.subsystems.ATag;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
//import org.firstinspires.ftc.teamcode.utils.Globals;
import org.firstinspires.ftc.teamcode.utils.Pose2D;

import java.util.List;

public class Limelight {
    private Telemetry telemetry;
    ATag aTag;
    private Limelight3A limelight;

    public Limelight(HardwareMap hwMap, Telemetry telemetry) {
        this.telemetry = telemetry;

        limelight = hwMap.get(Limelight3A.class, "limelight");

        limelight.setPollRateHz(100);
        limelight.pipelineSwitch(2);
        limelight.start();
    }

    public int scan () {
        LLResult result = limelight.getLatestResult();

        LLResultTypes.FiducialResult fiducial =
                result.getFiducialResults().get(0);
        int id = fiducial.getFiducialId();
        id = aTag.colorIDNumber();
        return id;
    }


//    private double targetX = 0;
//    private double targetA = 0;
//
//
//    public Pose2D cameraPose;
//    public double camX = 0;
//    public double camY = 0;
//    public double camH = 0;
//    private double alpha = 0.3;
//
//    public void update(boolean alliance) {
//        LLResult result = limelight.getLatestResult();
//        result.getBotpose();
//
//        if (result.isValid()) {
//            LLResultTypes.FiducialResult fiducial = result.getFiducialResults().get(0);
//
//
//            int id = fiducial.getFiducialId();
//
//            if ((id == 24 && alliance) || (id == 20 && !alliance)) {
//                targetX = fiducial.getTargetXDegrees();
//                targetA = fiducial.getTargetArea();
//                Position pos = fiducial.getRobotPoseFieldSpace().getPosition().toUnit(DistanceUnit.INCH);
//                double h = fiducial.getRobotPoseFieldSpace().getOrientation().getYaw(AngleUnit.DEGREES);
//                cameraPose = new Pose2D(pos.x, pos.y, h);
//                camX = pos.x;
//                camY = pos.y;
//                camH = h;
//
////                telemetry.addData("Target Area (% of image): ",  targetA);
////                telemetry.addData("X Degrees: ",  targetX);
//                telemetry.addData("Pos", pos.x + " : " + pos.y + " : " + h);
//            } else {
//                targetX = 0;
//                targetA = 1;
////                telemetry.addLine("Wrong april tag dude");
//            }
//        } else {
//            telemetry.addLine("Can't find april tag!");
//            targetX = 0;
//            targetA = 1;
//
//        }
//    }
//
//    public Pose2D getRobotPose() {
//
//
//        return null;
//    }
//
//    public double getTargetX() { return targetX; }
//
//    public double getTargetA() { return targetA; }

}