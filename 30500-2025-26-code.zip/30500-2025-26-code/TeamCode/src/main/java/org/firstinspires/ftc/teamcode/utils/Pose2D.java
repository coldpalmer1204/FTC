package org.firstinspires.ftc.teamcode.utils;

public class Pose2D {
    public double x, y, h;

    public Pose2D(double x, double y, double h) {
        this.x = x;
        this.y = y;
        this.h = h;
    }
}