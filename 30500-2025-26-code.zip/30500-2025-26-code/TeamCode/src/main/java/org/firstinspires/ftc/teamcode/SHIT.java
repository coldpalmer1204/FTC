package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.utils.Pose2D;

@Autonomous(name="aidan is stuped af and think someone will have better auto/ts will never be ran")
public class SHIT extends LinearOpMode {
    boolean blue = true;
    BunsBot buns =null;


    @Override
    public void runOpMode() throws InterruptedException {


        buns = new BunsBot(hardwareMap, telemetry, this);


//
//        while (opModeInInit()) {
//            if (gamepad1.x) {
//                blue=true;
//            } else if (gamepad1.b) {
//                blue=false;
//            }
//
//            buns.updateOuttake();
//
//            telemetry.addData("Alliance: ", blue ? "Blue" : "Red");
//            telemetry.update();
//        }
//
//        waitForStart();
//        for (int i = 0; i < 50; i++) {
//            buns.outtakeState = BunsBot.States.UP;
//            buns.updateOuttake();
//        }
//
//        sleep(250);
//        buns.backwards();
//        sleep(250);
//        if (blue) {
//            buns.strafeLeft();
//        } else {
//            buns.strafeRight();
//        }
//        sleep(500);
//        buns.drivetrain.setDrivePower(0, 0, 0, 0);


        buns.drivetrain.pinpoint.setPosition(new Pose2D(-49, -49, Math.toRadians(225)));


        buns.resetTimer();
        while (opModeInInit()) {


            if (gamepad1.x) {
                blue = true;
            } else if (gamepad1.b) {
                blue = false;
            }
            if (blue) {
                buns.drivetrain.pinpoint.setPosition(new Pose2D(60, -10, Math.toRadians(232)));
            } else {
                buns.drivetrain.pinpoint.setPosition(new Pose2D(60, 10, Math.toRadians(128)));
            }
            buns.outtakeState = BunsBot.States.DOWN;
//            buns.drivetrain.pinpoint.setPosition(new Pose2D(-49, 49, Math.toRadians(143)));
            buns.update();
            telemetry.addData("Alliance", (blue ? "Blue" : "Red"));
            telemetry.update();
        }


        waitForStart();


        if (blue) {
            buns.goToPoint(new Pose2D(60, 20, Math.toRadians(232)), false, 1);
        }
    }}
